<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenu sur le site</title>
</head>
<body>
<?php

?>
<!-- ici on peut voir les rapports, se déconnecter (ce qui ramène à l'acceuil) et consulter les medecins -->
<h2>Bienvuenue sur le site de location d'appartement</h2>
<a href="..\Vue\locationAppartement.php">différents appartement à louer</a>
<a href="..\vue\ListeMedecin.php">medecins</a>
<br><a href="..\Vue\acceuil.php">deconnexion</a></br>
</body>