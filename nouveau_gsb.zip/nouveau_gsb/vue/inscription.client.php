
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de création de client</title>
</head>
<body>

    <h2>Formulaire de création de client</h2>

    <form action="..\controlleur\traitement.client.php" method="post">
        <label for="prenom">Prénom:</label>
        <input type="text" id="prenom" name="prenom" required><br>

        <label for="nom">Nom:</label>
        <input type="text" id="nom" name="nom" required><br>

        <label for="login">Login:</label>
        <input type="text" id="login" name="login" required><br>

        <label for="mdp">Mot de passe:</label>
        <input type="password" id="mdp" name="mdp" required><br>

        <label for="adresse">vôtre adresse:</label>
        <input type="text" id="adresse" name="adresse" required><br>

        <label for="codePostal">vôtre code postal:</label>
        <input type="text" id="codePostal" name="codePostal" required><br>

        <label for="tel">Numéro de téléphone:</label>
        <input type="text" id="tel" name="tel" required><br>
            
        <input type="submit" value="Créer client">
    </form>

</body>
</html>

