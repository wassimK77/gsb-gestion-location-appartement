<?php
require "../modele/listeAppartement.php";

    if ($appartements) {
        // Boucle à travers les appartements récupérés
        foreach ($appartements as $appartement) {
            // Affichage des informations
            echo "Numéro d'appartement : " . $appartement['NUMAPPART'] . "<br>";
            echo "Rue : " . $appartement['RUE'] . "<br>";
            echo "Arrondissement : " . $appartement['ARRONDISSE'] . "<br>";
            echo "Étage : " . $appartement['ETAGE'] . "<br>";
            echo "Prix de location : " . $appartement['PRIX_LOC'] . "<br>";
            echo "Prix des charges : " . $appartement['PRIX_CHARG'] . "<br>";
            echo "Ascenseur : " . ($appartement['ASCENSEUR'] ? 'Oui' : 'Non') . "<br>";
            echo "Préavis : " . ($appartement['PREAVIS'] ? 'Oui' : 'Non') . "<br>";
            echo "Date libre : " . $appartement['DATE_LIBRE'] . "<br>";
            echo "Numéro de propriétaire : " . $appartement['NUMEROPROP'] . "<br>";
            echo "<hr>";
        }
    } else {
        // Aucun appartement trouvé
        echo "Aucun appartement trouvé.";
    }
?>

