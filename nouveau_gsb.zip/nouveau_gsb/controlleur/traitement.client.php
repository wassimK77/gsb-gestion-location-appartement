<?php
require "../modele/client.php";
require "../modele/bd.inc.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

$nom = $_POST["nom"];
$prenom = $_POST["prenom"];
$login = $_POST["login"];
$mdp = $_POST["mdp"];
$adresse= $_POST["adresse"];
$codePostal = $_POST["codePostal"];
$tel = $_POST["tel"];


$db = new Database();
$client = new client($db);

if ($client->insererclient($nom, $prenom, $adresse, $codePostal, $tel, $login, $mdp)) {

    echo "inscription réussi";
} else {
    echo "Erreur lors de l'inscription.";
}
header("Location: ../vue/AcceuilConnecter.php");
exit();
$client->closeConnection();
}
