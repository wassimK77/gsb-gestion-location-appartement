<?php

require '../modele/bd.inc.php';

class Appartement {
    private $connexion;

    public function __construct($connexion) {
        $this->connexion = $connexion;
    }

    public function recupererAppartements() {
        // Requête SQL pour sélectionner toutes les informations sur les appartements
        $requete = "SELECT * FROM appartements";

        // Exécution de la requête
        $resultat = $this->connexion->query($requete);

        // Vérification s'il y a des résultats
        if ($resultat->num_rows > 0) {
            // Récupération des données sous forme d'array associatif
            $appartements = [];
            while ($row = $resultat->fetch_assoc()) {
                $appartements[] = $row;
            }
            return $appartements;
        } else {
            // Aucun résultat trouvé
            return false;
        }
    }

}
?>
