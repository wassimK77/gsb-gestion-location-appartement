<?php
if (!class_exists('Database')){
class Database {
    private $host = "localhost";
    private $user = "root";
    private $password = "W.Kaouachi77";
    private $database = "location";

    protected $conn;

    public function __construct() {
        $this->conn = new mysqli($this->host, $this->user, $this->password, $this->database);

        if ($this->conn->connect_error) {
            die("Erreur de connexion à la base de données : " . $this->conn->connect_error);
        }
    }

    public function closeConnection() {
        $this->conn->close();
    }
}
}


?>
