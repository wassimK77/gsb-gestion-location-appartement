<?php

require 'bd.inc.php';


class client {
    private $nom;
    private $prenom;
    private $login;
    private $mdp;
    private $adresse;
    private $codePostal;
    private $tel;

    // Constructeur
    public function __construct($nom, $prenom, $adresse, $codePostal, $tel) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->login = $login;
        $this->mdp = password_hash($mdp, PASSWORD_DEFAULT); // Hash du mot de passe
        $this->adresse = $adresse;
        $this->codePostal = $codePostal;
        $this->tel = $tel;
    }

    // Getter pour l'ID/*  */
    public function getId() {
        return $this->id;
    }
}
?>
