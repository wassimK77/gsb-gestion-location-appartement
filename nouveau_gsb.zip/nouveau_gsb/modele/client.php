<?php
require "bd.inc.php";

class client {
    private $connexion;

    public function __construct($connexion) {
        $this->connexion = $connexion;
    }

public function insererClient($nom, $prenom, $adresse, $codePostal, $tel, $login, $mdp) {
    // Requête SQL pour sélectionner toutes les informations sur les appartements
    $requete = "INSERT INTO clients(NOM_CLI, PRENOM_CLI, ADRESSE_CLI, CODEVILLE_CLI, TEL_CLI, login, mdp) 
                VALUES (:nom , :prenom, :adresse , :codePostal, :tel, :login, :mdp)";

$statement = $this->connexion->;

    // Exécution de la requête
    $resultat = $statement->execute();

    // Vérification s'il y a des résultats
    if ($resultat->num_rows > 0) {
        // Récupération des données sous forme d'array associatif
        $clients = [];
        while ($row = $resultat->fetch_assoc()) {
            $clients[] = $row;
        }
        return $clients;
    } else {
        // Aucun résultat trouvé
        return false;
    }
}
}
?>
